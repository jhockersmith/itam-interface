let currentPage = 1;
const rowsPerPage = 15;
let csvLines = [];

fetch('input.csv')
    .then(response => response.text())
    .then(csvText => {
        csvLines = csvText.split("\n");
        displayCSVData();
    });

function displayCSVData() {
    const startIndex = (currentPage - 1) * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    const rows = csvLines.slice(startIndex, endIndex);
    let html = '<table>';

    rows.forEach((line, index) => {
        const columns = line.split(",");
        html += '<tr>';
        columns.forEach(column => {
            html += currentPage === 1 && index === 0 ? `<th>${column.trim()}</th>` : `<td>${column.trim()}</td>`;
        });
        html += '</tr>';
    });

    html += '</table>';
    document.getElementById('csvData').innerHTML = html;
    updateButtons();
}

function updateButtons() {
    document.getElementById('prevBtn').disabled = currentPage === 1;
    document.getElementById('nextBtn').disabled = currentPage >= Math.ceil((csvLines.length - 1) / rowsPerPage);
}

document.getElementById('prevBtn').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        displayCSVData();
    }
});

document.getElementById('nextBtn').addEventListener('click', () => {
    if (currentPage * rowsPerPage < csvLines.length) {
        currentPage++;
        displayCSVData();
    }
});

function displayCSVData() {
    const startIndex = (currentPage - 1) * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    const rows = csvLines.slice(startIndex, endIndex);
    let html = '<div class="csv-container"><table>';  // Wrap the table with a div

    rows.forEach((line, index) => {
        const columns = line.split(",");
        html += '<tr>';
        columns.forEach(column => {
            html += currentPage === 1 && index === 0 ? `<th>${column.trim()}</th>` : `<td>${column.trim()}</td>`;
        });
        html += '</tr>';
    });

    html += '</table></div>';  // Close the div
    document.getElementById('csvData').innerHTML = html;
    updateButtons();
}