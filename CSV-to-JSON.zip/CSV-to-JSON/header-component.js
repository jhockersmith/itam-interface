class HeaderComponent extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
    <div class="sidebar">
        <h1>Control Panel</h1>
        <a href="index.html">Overview</a>
        <a href="inventory.html">Inventory</a>
        <a href="lifecycle.html">Lifecycle</a>
        <a href="monitor.html">Monitor</a>
        <a href="licenses.html">Licenses</a>
        <a href="reporting">Reporting</a>
        <a href="permissions">Permissions</a>
        <a href="tagging">Tagging</a>
        <a href="alerts">Alerts</a>
        <a href="api-docs">API Docs</a>
        <a href="settings">Settings</a>
        <a href="#placeholder7">Placeholder 7</a>
        <a href="#placeholder8">Placeholder 8</a>
        <a href="#placeholder9">Placeholder 9</a>
        <a href="#placeholder10">Placeholder 10</a>
    </div>
        `;
    }
}

customElements.define('my-header', HeaderComponent);