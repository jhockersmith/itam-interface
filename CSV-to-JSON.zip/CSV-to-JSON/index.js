const express = require('express');
const fs = require('fs');
const app = express();
const port = 3000;

// Middleware to parse JSON bodies
app.use(express.json());

// Helper function to read data from output.json
function getItems() {
    const data = fs.readFileSync('output.json', 'utf8');
    return JSON.parse(data);
}

// Helper function to write data to output.json
function saveItems(items) {
    fs.writeFileSync('output.json', JSON.stringify(items, null, 2));
}

// GET all items
app.get('/api/items', (req, res) => {
    const items = getItems();
    res.json(items);
});

// GET a specific item by ID
app.get('/api/items/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const items = getItems();
    const item = items.find(i => i.id === id);
    if (item) {
        res.json(item);
    } else {
        res.status(404).send('Item not found');
    }
});

// POST a new item
app.post('/api/items', (req, res) => {
    const items = getItems();
    const newItem = {
        id: items.length + 1,
        name: req.body.name,
        description: req.body.description
    };
    items.push(newItem);
    saveItems(items);
    res.status(201).json(newItem);
});

// PUT (update) an existing item
app.put('/api/items/:id', (req, res) => {
    const id = parseInt(req.params.id);
    let items = getItems();
    const itemIndex = items.findIndex(i => i.id === id);
    if (itemIndex !== -1) {
        items[itemIndex] = {
            id: id,
            name: req.body.name,
            description: req.body.description
        };
        saveItems(items);
        res.json(items[itemIndex]);
    } else {
        res.status(404).send('Item not found');
    }
});

// DELETE an item
app.delete('/api/items/:id', (req, res) => {
    const id = parseInt(req.params.id);
    let items = getItems();
    items = items.filter(i => i.id !== id);
    saveItems(items);
    res.status(204).send();
});

// Start the server
app.listen(port, () => {
    console.log(`API running at http://localhost:${port}`);
});
