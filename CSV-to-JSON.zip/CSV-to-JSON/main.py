import csv
import json

def csv_to_json(csv_file_path, json_file_path):
    # Initialize an empty list to store the rows
    data = []

    # Open the CSV file
    with open(csv_file_path, mode='r', newline='') as csv_file:
        # Create a CSV DictReader object
        csv_reader = csv.DictReader(csv_file)

        # Iterate through each row in the CSV file
        for row in csv_reader:
            # Create a dictionary for each row and append it to the list
            data.append({
                "FirstName": row["First Name"],
                "LastName": row["Last Name"],
                "Email": row["Email"]
            })

    # Write the list of dictionaries to a JSON file
    with open(json_file_path, mode='w') as json_file:
        json.dump(data, json_file, indent=4)

# Example usage
csv_file_path = 'input.csv'  # Replace with the path to your CSV file
json_file_path = 'output.json'  # Replace with the path to save the JSON file

csv_to_json(csv_file_path, json_file_path)
