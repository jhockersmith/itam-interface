import json

# Load JSON data from the file
with open('output.json', 'r') as file:
    data = json.load(file)

# Loop through each entry in the JSON data and generate an email
for person in data:
    first_name = person.get('FirstName', 'Valued')
    last_name = person.get('LastName', 'Customer')
    email = person.get('Email', 'email@example.com')

    # Create the email content
    email_subject = f"Important Message for {first_name} {last_name}"
    email_body = f"""
    Dear {first_name} {last_name},

    I hope this message finds you well.

    We wanted to reach out to you regarding some important updates. Please feel free to contact us if you have any questions.

    Best regards,
    Your Company Name
    """

    # Print the email details (this simulates sending the email)
    print(f"To: {email}")
    print(f"Subject: {email_subject}")
    print(email_body)
    print("-" * 50)  # Separator between emails
